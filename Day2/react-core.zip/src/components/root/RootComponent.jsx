/* eslint-disable */

import React from 'react';
import ClassVsFunctionalComponents from '../1_class-vs-func/ClassVsFunctionalComponents';
import EventComponent from '../2_synthetic-events/EventComponent';
import CounterAssignment from '../3_counter-assignment/CounterAssignment';
import ControlledVsUncontrolledComponent from '../4_controlled-vs-uncontrolled/ControlledVsUncontrolledComponent';
import CalculatorAssignment from '../5_calculator-assignment/CalculatorAssignment';
import LCDemoComponent from '../6_lifecycle-demo/LCDemoComponent';
import PropTypesDemo from '../7_prop-types/PropTypesDemo';
import ListRoot from '../8_list-rendering/ListComponent';
import ErrorHandler from '../common/ErrorHandler';

const RootComponent = () => {
    return (
        <div className="container">
            <ErrorHandler>
                {/* <ClassVsFunctionalComponents /> */}
                {/* <EventComponent /> */}
                {/* <CounterAssignment /> */}
                {/* <ControlledVsUncontrolledComponent /> */}
                {/* <CalculatorAssignment /> */}
                {/* <LCDemoComponent /> */}
                {/* <PropTypesDemo /> */}
                <ListRoot />
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;