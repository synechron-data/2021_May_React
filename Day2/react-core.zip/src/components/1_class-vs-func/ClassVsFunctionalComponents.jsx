/* eslint-disable */

import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        console.log("State:", this.state);
        console.log("Props:", this.props);

        return (
            <h2 className="text-info">Using Class Syntax</h2>
        );
    }
}

// Functional / Stateless
const ComponentTwo = function () {
    console.log(this);
    return (
        <h2 className="text-info">Using Anonymous Function Syntax</h2>
    );
}

// Functional / Stateless
const ComponentThree = () => {
    console.log(this);
    return (
        <h2 className="text-info">Using Arrow Function Syntax</h2>
    );
}

// Functional / Stateless / Presentational
const ComponentFour = (props) => {
    console.log(props);
    // props.id = 100;                 // Error: props are readonly
    return (
        <h2 className="text-info">Using Arrow Function Syntax</h2>
    );
}

const ComponentFive = (props) => {
    var { id, name } = props;

    console.log("Id: ", id);
    console.log("Name: ", name);

    return (
        <h2 className="text-info">Using Arrow Function Syntax</h2>
    );
}

const ComponentSix = ({ id, name }) => {
    console.log("Id: ", id);
    console.log("Name: ", name);

    return (
        <h2 className="text-info">Using Arrow Function Syntax</h2>
    );
}

const ComponentSeven = ({ id, name, ...address }) => {
    console.log("Id: ", id);
    console.log("Name: ", name);
    console.log("Address: ", address);

    return (
        <h2 className="text-info">Using Arrow Function Syntax</h2>
    );
}

const ClassVsFunctionalComponents = () => {
    return (
        <div>
            {/* <ComponentOne /> */}
            {/* <ComponentTwo /> */}
            {/* <ComponentThree /> */}
            {/* <ComponentFour id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
            {/* <ComponentFive id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
            {/* <ComponentSix id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
            <ComponentSeven id={1} name={"Manish"} city={"Pune"} state={"MH"} />
        </div>
    );
};

export default ClassVsFunctionalComponents;