import React, { Component } from 'react';

import './ComponentTwo.css';

class ComponentTwo extends Component {
    render() {
        return (
            <>
                <h1 className="text-success">Hello from Component Two</h1>
                <h2 className="card2 text-success">From Component Two</h2>
            </>
        );
    }
}

export default ComponentTwo;