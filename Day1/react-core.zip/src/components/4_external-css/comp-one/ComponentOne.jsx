import React, { Component } from 'react';

import './ComponentOne.css';

class ComponentOne extends Component {
    render() {
        return (
            <>
                <h1 className="text-info">Hello from Component One</h1>
                <h2 className="card1 text-info">From Component One</h2>
            </>
        );
    }
}

export default ComponentOne;