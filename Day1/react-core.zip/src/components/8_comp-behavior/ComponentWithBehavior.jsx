import React, { Component } from 'react';

class ChildComponent extends Component {
    render() {
        return (
            <div>
                <h3 className="text-success">Child Component</h3>
                <h3 className="text-success">Count: {this.props.data}</h3>
            </div>
        );
    }
}

class ComponentWithBehavior extends Component {
    constructor(props) {
        super(props);
        this.state = { id: 1, count: 0 };
    }

    handleClick() {
        // alert("Clicked....");
        // console.log("handleClick", this);

        // If you want the UI to be in sync with current state, 
        // Do not mutate state directly. Instead Use setState()
        // this.state.count += 1;
        // console.log(this.state);

        // setState() is an async function
        // this.setState({ count: this.state.count + 1 });
        // console.log(this.state);

        this.setState({ count: this.state.count + 1 }, () => {
            console.log(this.state);
        });
    }

    render() {
        return (
            <div>
                <h2 className="text-info">Id: {this.state.id}</h2>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.handleClick.bind(this)}>Click</button>
                <hr />
                <ChildComponent data={this.state.count} />
            </div>
        );
    }
}

export default ComponentWithBehavior;