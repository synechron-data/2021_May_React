import React, { Component } from 'react';

import { card } from './ComponentTwo.module.css';

class ComponentTwo extends Component {
    render() {
        return (
            <>
                <h1 className="text-success">Hello from Component Two</h1>
                <h2 className={`text-success ${card}`}>From Component Two</h2>
            </>
        );
    }
}

export default ComponentTwo;