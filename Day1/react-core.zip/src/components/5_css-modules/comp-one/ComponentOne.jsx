import React, { Component } from 'react';

import styles from './ComponentOne.module.css';

class ComponentOne extends Component {
    render() {
        return (
            <>
                <h1 className="text-info">Hello from Component One</h1>
                <h2 className={`text-info ${styles.card}`}>From Component One</h2>
            </>
        );
    }
}

export default ComponentOne;