import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);

        this.state = { name: "Synechron" };
        // this.props = { name: "Synechron" };         // Props Cannot Initialized like state
        // this.props.name = "Abhijeet";               // Error - Props are readonly

        // Reference Copy
        // It is not recommended to assign props directly to 
        // state because updates to props won't be reflected in state.
        // this.state = this.props;
        // this.state.name = "Abhijeet";               // Error - Props are readonly

        // Shallow Copy
        // this.state = Object.assign({}, this.props);     // ECMASCRIPT 2015 - Object.assign
        // this.state = { ...this.props };                  // ECMASCRIPT 2018 - Object Spread 
        // this.state.name = "Abhijeet";
        // this.state.address.city = "Mumbai"

        // Deep Copy - Will not copy functions
        this.state = JSON.parse(JSON.stringify(this.props));
        this.state.name = "Abhijeet";
        this.state.address.city = "Mumbai"

        // Deep Copy with Functions - Lodash, immutability-helper

        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);
    }

    render() {
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);

        return (
            <div>
                <h1 className="text-info">Component With Props</h1>
            </div>
        );
    }
}

export default ComponentWithProps;