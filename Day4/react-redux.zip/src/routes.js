import { lazy, Suspense } from "react";
import { Route, Switch } from "react-router";

import HomeComponent from "./components/home/HomeComponent";
import LoaderAnimation from './components/common/LoaderAnimation';

const AboutContainer = lazy(() => import("./containers/about/AboutContainer"));
const HOCDemo = lazy(() => import("./components/hoc/HOCDemo"));
const CounterContainer = lazy(() => import("./containers/counter/CounterContainer"));
const ProductsContainer = lazy(() => import("./containers/products/ProductsContainer"));
const ManageProductContainer = lazy(() => import("./containers/products/ManageProductContainer"));

const img404 = require('./assets/404_page.jpg').default;

export default (
    <Suspense fallback={<LoaderAnimation />}>
        <Switch>
            <Route exact path="/" component={HomeComponent} />
            <Route path="/about" component={AboutContainer} />
            <Route path="/hoc" component={HOCDemo} />
            <Route path="/counter" component={CounterContainer} />
            <Route path="/products" component={ProductsContainer} />
            <Route path="/product/:id" component={ManageProductContainer} />
            <Route path="/product" component={ManageProductContainer} />
            <Route path="**" render={
                () => (
                    <div className="text-center mt-5">
                        <article>
                            <h1 className="text-danger">No Route Configured!</h1>
                            <h4 className="text-danger">Please check your Route Configuration</h4>
                        </article>
                        <img src={img404} alt="Not Found" className="rounded mt-5" />
                    </div>
                )
            } />
        </Switch>
    </Suspense>
);