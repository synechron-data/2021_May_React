import * as actiontypes from './actionTypes';
import productsAPIClient from '../services/products.service';

import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actiontypes.LOAD_PRODUCTS_REQUESTED,
        payload: { message: msg, flag: false }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actiontypes.LOAD_PRODUCTS_SUCCESS,
        payload: { data: products, message: msg, flag: true }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actiontypes.LOAD_PRODUCTS_FAILED,
        payload: { message: msg, flag: true }
    };
}

export function loadProducts() {
    // Thunk Function
    return function (dispatch) {
        dispatch(loadProductsRequested("Products Request Started..."));

        productsAPIClient.getAllProducts().then(products => {
            setTimeout(() => {
                dispatch(loadProductsSuccess(products, "Products Request Completed Successfully"))
            }, 5000);
        }).catch(eMsg => {
            dispatch(loadProductsFailed(eMsg));
        });
    }
}

// ----------------------------------------------------- INSERT

function insertProductSuccess(product, msg) {
    return {
        type: actiontypes.INSERT_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function insertProduct(product) {
    return function (dispatch) {
        // Dispatch to Insert Requested

        productsAPIClient.insertProduct(product).then(insertedProduct => {
            dispatch(insertProductSuccess(insertedProduct, "Product Inseted Successfully"));
            history.push('/products');
        }).catch(eMsg => {
            // Dispatch to Insert Failed
            console.error(eMsg);
        });
    }
}

// ----------------------------------------------------- UPDATE

function updateProductSuccess(product, msg) {
    return {
        type: actiontypes.UPDATE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function updateProduct(product) {
    return function (dispatch) {
        // Dispatch to Update Requested

        productsAPIClient.updateProduct(product).then(updatedProduct => {
            dispatch(updateProductSuccess(updatedProduct, "Product Updated Successfully"));
            history.push('/products');
        }).catch(eMsg => {
            // Dispatch to Update Failed
            console.error(eMsg);
        });
    }
}

// ----------------------------------------------------- DELETE

function deleteProductSuccess(product, msg) {
    return {
        type: actiontypes.DELETE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function deleteProduct(product) {
    return function (dispatch) {
        // Dispatch to Update Requested

        productsAPIClient.deleteProduct(product).then(_ => {
            dispatch(deleteProductSuccess(product, "Product Deleted Successfully"));
        }).catch(eMsg => {
            // Dispatch to Update Failed
            console.error(eMsg);
        });
    }
}