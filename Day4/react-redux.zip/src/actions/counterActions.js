import * as actiontypes from './actionTypes';

// Action Creator
export function incCounter(interval = 1) {
    // Creates and Returns an Action Object
    return {
        type: actiontypes.INCREMENT_COUNTER,
        payload: interval
    };
}

// Action Creator
export function decCounter(interval = 1) {
    // Creates and Returns an Action Object
    return {
        type: actiontypes.DECREMENT_COUNTER,
        payload: interval
    };
}

// Action Creator
export function mulCounter(interval = 1) {
    // Creates and Returns an Action Object
    return {
        type: actiontypes.MULTIPLY_COUNTER,
        payload: interval
    };
}