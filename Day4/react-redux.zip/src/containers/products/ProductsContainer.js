import React, { Component } from 'react';
import { connect } from 'react-redux';

import LoaderAnimation from '../../components/common/LoaderAnimation';

import * as productActions from '../../actions/productActions';
import ProductListComponent from '../../components/products/ProductListComponent';
import AddProductButton from '../../components/products/AddProductButton';

class ProductsContainer extends Component {
    render() {
        return (
            <>
                <br />
                <br />
                <AddProductButton />
                <br />
                <br />
                {
                    this.props.flag ?
                        <>
                            <ProductListComponent products={this.props.products} onDelete={
                                (p, e) => {
                                    this.props.deleteProduct(p);
                                }
                            } />
                        </> :
                        <div className="pt-5">
                            <LoaderAnimation />
                        </div>
                }
            </>
        );
    }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer.products,
        status: state.productReducer.status,
        flag: state.productReducer.flag
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => { dispatch(productActions.loadProducts()); },
        deleteProduct: (product) => { dispatch(productActions.deleteProduct(product)); }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);