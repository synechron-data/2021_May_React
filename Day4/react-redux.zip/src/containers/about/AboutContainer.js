import React, { Component } from 'react';
import { connect } from 'react-redux';
import AboutComponent from '../../components/about/AboutComponent';

class AboutContainer extends Component {
    render() {
        return (
            <div>
                <AboutComponent count={this.props.count}/>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        count: state.counterReducer
    };
}

function mapDispatchToProps(dispatch) {
    return {

    };
}

export default connect(mapStateToProps, mapDispatchToProps)(AboutContainer);