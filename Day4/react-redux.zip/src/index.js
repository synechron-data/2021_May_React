import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import 'bootstrap';
import RootComponent from './components/root/RootComponent';
import configureStore from './store/configureStore';

// const store = configureStore();
// console.log(store);
// console.log(store.getState());

// const store = configureStore({ counterReducer: 100 });
// console.log(store.getState());

const appStore = configureStore();

ReactDOM.render(
  <React.StrictMode>
    <Provider store={appStore}>
      <RootComponent />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);