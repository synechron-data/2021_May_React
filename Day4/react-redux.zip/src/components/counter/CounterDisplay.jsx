import React from 'react';

const CounterDisplay = (props) => {
    return (
        <div>
            <h2>Current Count: {props.count}</h2>
        </div>
    );
};

export default CounterDisplay;