import React from 'react';

const AboutComponent = (props) => {
    return (
        <div>
            <div>
                <h1 className="text-info">About Component</h1>
                <h4 className="text-warning">This is a Simple, React Redux Application</h4>
                <h4 className="text-warning">Current Count: {props.count}</h4>
            </div>
        </div>
    );
};

export default AboutComponent;