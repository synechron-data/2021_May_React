// import React from 'react';
// import { BrowserRouter } from 'react-router-dom';

// import NavigationComponent from '../bs-nav/NavigationComponent';
// import ErrorHandler from '../common/ErrorHandler';

// const RootComponent = () => {
//     return (
//         <div className="container">
//             <BrowserRouter>
//                 <ErrorHandler>
//                     <NavigationComponent />
//                 </ErrorHandler>
//             </BrowserRouter>
//         </div>
//     );
// };

// export default RootComponent;

// ------------------------------------------------------------------

import React from 'react';
import { Router } from 'react-router-dom';

import history from '../../history';

import NavigationComponent from '../bs-nav/NavigationComponent';
import ErrorHandler from '../common/ErrorHandler';

const RootComponent = () => {
    return (
        <div className="container">
            <Router history={history}>
                <ErrorHandler>
                    <NavigationComponent />
                </ErrorHandler>
            </Router>
        </div>
    );
};

export default RootComponent;