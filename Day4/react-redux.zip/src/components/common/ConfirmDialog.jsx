import React from 'react';
import { Modal, Button } from 'react-bootstrap';

const ConfirmDialog = ({ show, header, body, handleYes, handleNo }) => {
    return (
        <>
            <Modal show={show} onHide={handleNo} animation={false}>
                <Modal.Header closeButton>
                    <Modal.Title>{header || "Confirm Dialog"}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {body}
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={handleYes}>
                        Yes
                    </Button>
                    <Button variant="danger" onClick={handleNo}>
                        No
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

export default ConfirmDialog;