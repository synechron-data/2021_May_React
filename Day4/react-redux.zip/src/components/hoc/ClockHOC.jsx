import { Component } from "react";

const ClockHOC = (InputComponent) => class extends Component {
    constructor(props) {
        super(props);
        this.state = { currentTime: new Date().toLocaleTimeString() };
    }

    render() {
        return (
            <>
                <div className="lead text-right font-weight-bold text-primary">
                    {this.state.currentTime}
                </div>
                <InputComponent />
            </>
        );
    }

    componentDidMount() {
        setInterval(() => {
            this.setState({ currentTime: new Date().toLocaleTimeString() });
        }, 1000);
    }

}

export default ClockHOC;