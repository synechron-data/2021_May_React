import React, { Component } from 'react';
import ClockHOC from './ClockHOC';

class HOCDemo extends Component {
    render() {
        // throw new Error("Just for Fun");
        return (
            <div>
                <h1 className="text-info">Higher Order Component Demo</h1>
                <h2 className="text-success">Some Data, added by HOC: {this.props.data}</h2>
            </div>
        );
    }
}

// HOC for Error Boundry
const componentEnhancer = InputComponent => class extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    componentDidMount() {
        this.setState({ data: "Hello from HOC" });
    }

    render() {
        if (this.state.hasError) {
            return <h2 className="text-danger">Error Caught</h2>;
        } else
            return <InputComponent {...this.state} {...this.props} />
    }

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }
}

// const componentEnhancer = InputComponent => class extends Component {
//     componentDidMount() {
//         this.setState({ data: "Hello from HOC" });
//     }

//     render() {
//         return <InputComponent {...this.state} {...this.props} />
//     }
// }

// const componentEnhancer = (InputComponent) => {
//     return class extends Component {
//         componentDidMount() {
//             this.setState({ data: "Hello from HOC" });
//         }

//         render() {
//             return <InputComponent {...this.state} {...this.props}/>
//         }
//     }
// }

// const componentEnhancer = function (InputComponent) {
//     return class extends Component {
//         componentDidMount() {
//             this.setState({ data: "Hello from HOC" });
//         }

//         render() {
//             return <InputComponent {...this.state} {...this.props}/>
//         }
//     }
// }

// function componentEnhancer(InputComponent) {
//     return class extends Component {
//         componentDidMount() {
//             this.setState({ data: "Hello from HOC" });
//         }

//         render() {
//             return <InputComponent {...this.state} {...this.props}/>
//         }
//     }
// }

export default ClockHOC(componentEnhancer(HOCDemo));

// export default componentEnhancer(HOCDemo);

// const enhancedHOCDemo = componentEnhancer(HOCDemo);
// export default enhancedHOCDemo;

// export default HOCDemo;