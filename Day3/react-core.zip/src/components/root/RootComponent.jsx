/* eslint-disable */

import React from 'react';
import CrudAssignment from '../1_crud-app/CrudAssignment';
import PureImpureRoot from '../2_pure-impure/PureImpureRoot';
import AjaxAssignment from '../3_ajax/AjaxAssignment';
import AjaxComponent from '../3_ajax/AjaxComponent';
import ContextAPIDemo from '../4_context-api/ContextAPIDemo';
import EffectHookDemo from '../5_hooks/EffectHookDemo';
import StateHookDemo from '../5_hooks/StateHookDemo';
import PortalRoot from '../6_portals/PortalRoot';
import ErrorHandler from '../common/ErrorHandler';

const RootComponent = () => {
    return (
        <div className="container">
            <ErrorHandler>
                {/* <CrudAssignment /> */}
                {/* <PureImpureRoot /> */}
                {/* <AjaxComponent /> */}
                {/* <AjaxAssignment /> */}
                {/* <ContextAPIDemo /> */}
                {/* <StateHookDemo /> */}
                {/* <EffectHookDemo /> */}
                <PortalRoot />
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;