// import React, { Component } from 'react';

// class ImpureComponent extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { count: 0 };
//     }

//     render() {
//         console.log("Impure - Render Called....");
//         return (
//             <h2>Count Value is: {this.state.count}</h2>
//         );
//     }

//     componentDidMount() {
//         setInterval(() => {
//             // this.setState({ count: this.state.count + 1 });
//             this.setState({ count: 0 });
//         }, 1000);
//     }
// }

// export default ImpureComponent;

// ---------------------------------------------------------------- With Reference Types

import React, { Component } from 'react';

class ImpureComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { numbers: [1, 2] };
    }

    render() {
        console.log("Impure - Render Called....");
        return (
            <h2>Array Length is: {this.state.numbers.length}</h2>
        );
    }

    componentDidMount() {
        setInterval(() => {
            var last = this.state.numbers[this.state.numbers.length - 1];
            this.state.numbers.push((last + 1));
            this.setState({ numbers: this.state.numbers }, () => {
                console.log(this.state.numbers);
            });
        }, 1000);
    }
}

export default ImpureComponent;
