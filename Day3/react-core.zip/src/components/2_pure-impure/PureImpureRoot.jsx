/* eslint-disable */

import React from 'react';
import ImpureComponent from './ImpureComponent';
import MyPureComponent from './PureComponent';

const PureImpureRoot = () => {
    return (
        <div>
            <h2 className="text-info">Pure and Impure Components</h2>
            <ImpureComponent />
            {/* <MyPureComponent /> */}
        </div>
    );
};

export default PureImpureRoot;