// import React, { Component } from 'react';

// class MyPureComponent extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { count: 0 };
//     }

//     render() {
//         console.log("Pure - Render Called....");
//         return (
//             <h2>Count Value is: {this.state.count}</h2>
//         );
//     }

//     shouldComponentUpdate(nextProps, nextState) {
//         if (this.state.count !== nextState.count)
//             return true;
//         else
//             return false;
//     }

//     componentDidMount() {
//         setInterval(() => {
//             // this.setState({ count: this.state.count + 1 });
//             this.setState({ count: 0 });
//         }, 1000);
//     }
// }

// export default MyPureComponent;

// ------------------------------------------------------------------
// import React, { PureComponent } from 'react';

// class MyPureComponent extends PureComponent {
//     constructor(props) {
//         super(props);
//         this.state = { count: 0 };
//     }

//     render() {
//         console.log("Pure - Render Called....");
//         return (
//             <h2>Count Value is: {this.state.count}</h2>
//         );
//     }

//     componentDidMount() {
//         setInterval(() => {
//             // this.setState({ count: this.state.count + 1 });
//             this.setState({ count: 0 });
//         }, 1000);
//     }
// }

// export default MyPureComponent;

// ------------------------------------------------------------------ With Reference Type
import React, { PureComponent } from 'react';

class MyPureComponent extends PureComponent {
    constructor(props) {
        super(props);
        this.state = { numbers: [1, 2] };
    }

    // When you are using Pure Components with Reference Types,
    // The render will be called only if Reference is changed
    render() {
        console.log("Pure - Render Called....");
        return (
            <h2>Array Length is: {this.state.numbers.length}</h2>
        );
    }

    componentDidMount() {
        // setInterval(() => {
        //     var last = this.state.numbers[this.state.numbers.length - 1];
        //     this.state.numbers.push((last + 1));
        //     this.setState({ numbers: this.state.numbers }, () => {
        //         console.log(this.state.numbers);
        //     });
        // }, 1000);

        setInterval(() => {
            var last = this.state.numbers[this.state.numbers.length - 1];
            this.setState({ numbers: [...this.state.numbers, (last + 1)] }, () => {
                console.log(this.state.numbers);
            });
        }, 1000);
    }
}

export default MyPureComponent;