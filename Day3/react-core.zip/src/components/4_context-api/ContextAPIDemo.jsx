// import React, { Component } from 'react';
// import postsApiClient from '../../services/posts.service';
// import DataTable from '../common/DataTable';
// import LoaderAnimation from '../common/LoaderAnimation';

// class ChildComponentTwo extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child Two</h3>
//                 <DataTable items={this.props.data}>
//                     <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
//                 </DataTable>
//             </div>
//         );
//     }
// }

// class ChildComponentOne extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child One</h3>
//                 <ChildComponentTwo data={this.props.data} />
//             </div>
//         );
//     }
// }

// class ContextAPIDemo extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { posts: [], message: "<----- Click the Button to Load Data", flag: true };
//         this.loadData = this.loadData.bind(this);
//     }

//     render() {
//         return (
//             <>
//                 <div className="row mt-5 mb-5">
//                     <div className="col-2">
//                         <button className="btn btn-primary btn-block" onClick={this.loadData}>Load Data</button>
//                     </div>
//                     <div className="col">
//                         <h4 className="text-warning text-center text-uppercase font-weight-bold">{this.state.message}</h4>
//                     </div>
//                 </div>

//                 {
//                     !this.state.flag ?
//                         <div>
//                             <LoaderAnimation />
//                         </div> : null
//                 }

//                 <ChildComponentOne data={this.state.posts} />
//             </>
//         );
//     }

//     loadData() {
//         this.setState({ flag: false });
//         postsApiClient.getAllPosts().then(data => {
//             this.setState({ posts: [...data], flag: true });
//         }).catch(eMsg => {
//             this.setState({ posts: [], message: eMsg, flag: true });
//         });
//     }
// }

// export default ContextAPIDemo;

// ------------------------------------------------------------------------------

import React, { Component } from 'react';
import postsApiClient from '../../services/posts.service';
import DataTable from '../common/DataTable';
import LoaderAnimation from '../common/LoaderAnimation';

// const obj = React.createContext();
// console.log(obj);

const { Provider, Consumer } = React.createContext();

const C1 = React.createContext();
const C2 = React.createContext();

class ChildComponentTwo extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child Two</h3>
                <C1.Consumer>
                    {
                        (data) => (
                            <h1 className="text-info">{data}</h1>
                        )
                    }
                </C1.Consumer>
                <C2.Consumer>
                    {
                        (data) => (
                            <h1 className="text-success">{data}</h1>
                        )
                    }
                </C2.Consumer>
                <Consumer>
                    {
                        (data) => (
                            <DataTable items={data}>
                                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                            </DataTable>
                        )
                    }
                </Consumer>
            </div>
        );
    }
}

class ChildComponentOne extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child One</h3>
                <ChildComponentTwo />
            </div>
        );
    }
}

class ContextAPIDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "<----- Click the Button to Load Data", flag: true };
        this.loadData = this.loadData.bind(this);
    }

    render() {
        return (
            <>
                <div className="row mt-5 mb-5">
                    <div className="col-2">
                        <button className="btn btn-primary btn-block" onClick={this.loadData}>Load Data</button>
                    </div>
                    <div className="col">
                        <h4 className="text-warning text-center text-uppercase font-weight-bold">{this.state.message}</h4>
                    </div>
                </div>

                {
                    !this.state.flag ?
                        <div>
                            <LoaderAnimation />
                        </div> : null
                }

                {/* <Provider value={this.state.posts}>
                    <ChildComponentOne />
                </Provider> */}

                <C1.Provider value={"Data from C1"}>
                    <C2.Provider value={"Data from C2"}>
                        <Provider value={this.state.posts}>
                            <ChildComponentOne />
                        </Provider>
                    </C2.Provider>
                </C1.Provider>
            </>
        );
    }

    loadData() {
        this.setState({ flag: false });
        postsApiClient.getAllPosts().then(data => {
            this.setState({ posts: [...data], flag: true });
        }).catch(eMsg => {
            this.setState({ posts: [], message: eMsg, flag: true });
        });
    }
}

export default ContextAPIDemo;