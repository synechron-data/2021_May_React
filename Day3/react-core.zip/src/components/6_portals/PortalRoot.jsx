import React, { Component } from 'react';
import './PortalRoot.css';
import WithoutPortal from './WithoutPortal';
import WithPortal from './WithPortal';

class PortalRoot extends Component {
    constructor(props) {
        super(props);
        this.state = { mflag: false, pflag: false };
        this.setmFlag = this.setmFlag.bind(this);
        this.setpFlag = this.setpFlag.bind(this);
    }

    setmFlag(f) {
        this.setState({ mflag: f });
    }

    setpFlag(f) {
        this.setState({ pflag: f });
    }

    render() {
        return (
            <div className="app-container" >
                <div className="button-container">
                    <button className="button" onClick={() => { this.setmFlag(true); }}>
                        Without Portal
                    </button>
                    <button className="button" onClick={() => { this.setpFlag(true); }}>
                        With Portal
                    </button>
                </div>

                <WithoutPortal message="Hello, I am a Modal Window" isOpen={this.state.mflag}
                    onClose={() => { this.setmFlag(false); }} />

                <WithPortal message="Hello, I am a Portal Modal Window" isOpen={this.state.pflag}
                    onClose={() => { this.setpFlag(false); }} />
            </div>
        );
    }
}

export default PortalRoot;