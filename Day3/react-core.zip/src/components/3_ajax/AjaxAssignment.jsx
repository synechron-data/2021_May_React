import React, { Component } from 'react';
import usersApiClient from '../../services/users.service';

class AjaxAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = { users: [], message: "Loading Data, please wait...", flag: false };
    }

    render() {
        let optionItems = this.state.users.map((user) =>
            <option key={user.id}>{user.name}</option>
        );
        return (
            <div className="row justify-content-md-center mt-5">
                <form className="col-md-6">
                    <div className="form-group">
                        <label htmlFor="username">User *</label>
                        <select id="username" className='form-control' disabled={!this.state.flag}>
                            <option value="" disabled>Please select an User</option>
                            {optionItems}
                        </select>
                    </div>
                </form>
            </div>
        );
    }

    componentDidMount() {
        usersApiClient.getAllUsers().then(data => {
            this.setState({ users: [...data], message: "", flag: true });
        }).catch(eMsg => {
            this.setState({ users: [], message: eMsg, flag: true });
        });
    }
}

export default AjaxAssignment;

// https://jsonplaceholder.typicode.com/users/1/posts
// After selecting the user, display details of that user and all the posts which the user have made