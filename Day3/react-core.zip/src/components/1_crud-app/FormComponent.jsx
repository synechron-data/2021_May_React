import React from 'react';
import TextInput from '../common/TextInput';

const FormComponent = (props) => {
    return (
        <div className="row">
            <div className="col-sm-6 offset-sm-3">
                <form className="form-horizontal" autoComplete="off" onSubmit={e => {
                    e.preventDefault();
                    props.onSave(e);
                }}>
                    <fieldset>
                        <legend className="text-center text-secondary text-uppercase font-weight-bold">Add Employee Information</legend>
                        <hr className="mt-0" />
                        
                        <TextInput label={"Id"} name={"id"} readOnly={true} type={"number"} value={props.employee.id}
                            onChange={props.onUpdateState} />
                        <TextInput label={"Name"} name={"name"} value={props.employee.name}
                            onChange={props.onUpdateState} />
                        <TextInput label={"Designation"} name={"designation"} value={props.employee.designation}
                            onChange={props.onUpdateState} />
                        <TextInput label={"Salary"} name={"salary"} value={props.employee.salary}
                            onChange={props.onUpdateState} />

                        <div className="row mt-3">
                            <div className="col">
                                <button type="submit" className="btn btn-success btn-block">Save</button>
                            </div>
                            <div className="col">
                                <button type="reset" className="btn btn-primary btn-block">Reset</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    );
};

export default FormComponent;