import React, { useEffect, useState } from 'react';
import postsApiClient from '../../services/posts.service';
import DataTable from '../common/DataTable';
import LoaderAnimation from '../common/LoaderAnimation';

const BasicDemo = () => {
    const [person, setPerson] = useState({ fname: "Manish", lname: "Sharma" });

    // Without Second Parameter, it behaves like ComponentDidUpdate()
    // With Second Parameter, it behaves like ComponentDidMount()

    useEffect(() => {
        console.log("useEffect is called...");
        setTimeout(() => {
            setPerson({ fname: "Abhijeet", lname: "Gole" })
        }, 5000);
    }, []);

    return (
        <div>
            <h3>Firstname: {person.fname}</h3>
            <h3>Lastname: {person.lname}</h3>
        </div>
    );
}

const AjaxDemo = () => {
    const [posts, setPosts] = useState([]);
    const [message, setMessage] = useState('Loading Data, please wait...');
    const [flag, setFlag] = useState(false);

    useEffect(() => {
        postsApiClient.getAllPosts().then(data => {
            setPosts(data);
            setMessage("");
            setFlag(true);
        }).catch(eMsg => {
            setMessage(eMsg);
            setFlag(true);
        })
    }, []);

    return (
        <>
            <div className="row">
                <h4 className="text-warning text-center text-uppercase font-weight-bold">{message}</h4>
            </div>

            {
                !flag ?
                    <div className="pt-5">
                        <LoaderAnimation />
                    </div> : null
            }

            <DataTable items={posts}>
                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
            </DataTable>
        </>
    );
}

const EffectHookDemo = () => {
    return (
        <div>
            <BasicDemo />
            <hr />
            <AjaxDemo />
        </div>
    );
};

export default EffectHookDemo;